package cpcs324.project.phase2;

// Group 4: 
// Ethar Nasser Alahmari 1807758
// Rahaf Ibrahim Braiji 1805651
// Sara Abdulilah Alhaifi 1807468

import java.util.HashSet;
import java.util.Set;

import java.util.*;

class Graph_pq {

    int dist[];
    Set<Integer> visited;
    PriorityQueue<Node> pqueue;
    int V; // Number of vertices 
    List<List<Node>> adj_list;

    //class constructor
    public Graph_pq(int V) {
        this.V = V;
        dist = new int[V];
        visited = new HashSet<Integer>();
        pqueue = new PriorityQueue<Node>(V, new Node());
    }

    // Dijkstra's Algorithm implementation 
    public void algo_dijkstra(List<List<Node>> adj_list, int src_vertex) {
        this.adj_list = adj_list;
        for (int i = 0; i < V; i++) {
            dist[i] = Integer.MAX_VALUE;
        }

        // first add source vertex to PriorityQueue 
        pqueue.add(new Node(src_vertex, 0));
        System.out.println("\n- Start with:");
        System.out.println("Jeddah (- ,0)");
        System.out.println("\n----------------------");
        
        // Distance to the source from itself is 0 
        dist[src_vertex] = 0;
        
        ArrayList<city> remain = new ArrayList<>();//Creating arraylist to store the Remaining Vertices 
        ArrayList<city> visit = new ArrayList<>();//Creating arraylist to store the Tree Vertices 
        
        while (visited.size() != V) {
            Node n = pqueue.remove();
            
            // u is removed from PriorityQueue and has min distance  
            int u = n.node;
            
            // add node to finalized list (visited)
            visited.add(u);
            visit.add(new city(n.node, n.cost));
            
            // display tracing
            if (pqueue.size()!=0){
            System.out.println("\n- Tree Vertices:");
            for (int i = 0; i < visit.size(); i++) {
                System.out.println(visit.get(i).destination + "\t (Jeddah ," + visit.get(i).distance + ")");
            }

            System.out.println("\n- Remaining Vertices:");
            int size = pqueue.size();
            for (int i = 0; i < size; i++) {
                Node node = pqueue.poll();
                remain.add(new city(node.node, node.cost));
            }
            for (int i = 0; i < remain.size(); i++) {
                System.out.println(remain.get(i).destination + "\t (Jeddah ," + remain.get(i).distance + ")");
            }
            System.out.println("\n----------------------");
            }
            
            // update cost 
            graph_adjacentNodes(u);
            // clear remaining arraylist 
            remain.clear();

        }
    }
    
    // this methods processes all neighbours of the just visited node
    private void graph_adjacentNodes(int u) {
        int edgeDistance = -1;
        int newDistance = -1;

        // process all neighbouring nodes of u 
        for (int i = 0; i < adj_list.get(u).size(); i++) {
            Node v = adj_list.get(u).get(i);

            //  proceed only if current node is not in 'visited'
            if (!visited.contains(v.node)) {
                edgeDistance = v.cost;
                newDistance = dist[u] + edgeDistance;

                // compare distances 
                if (newDistance < dist[v.node]) {
                    dist[v.node] = newDistance;
                }

                // Add the current vertex to the PriorityQueue 
                pqueue.add(new Node(v.node, dist[v.node]));
            }
        }
    }

}

class Main {

    public static void main(String arg[]) {
        int V = 12;
        int source = 0;
        // adjacency list representation of graph
        List<List<Node>> adj_list = new ArrayList<List<Node>>();
        // Initialize adjacency list for every node in the graph 
        for (int i = 0; i < V; i++) {
            List<Node> item = new ArrayList<Node>();
            adj_list.add(item);
        }

        // Input graph edges  from jeddah to other city
        adj_list.get(0).add(new Node(0, 0));
        adj_list.get(0).add(new Node(1, 79));
        adj_list.get(0).add(new Node(2, 420));
        adj_list.get(0).add(new Node(3, 949));
        adj_list.get(0).add(new Node(4, 1343));
        adj_list.get(0).add(new Node(5, 167));
        adj_list.get(0).add(new Node(6, 625));
        adj_list.get(0).add(new Node(7, 1024));
        adj_list.get(0).add(new Node(8, 863));
        adj_list.get(0).add(new Node(9, 777));
        adj_list.get(0).add(new Node(10, 710));
        adj_list.get(0).add(new Node(11, 905));
        //from makkah to others   
        adj_list.get(1).add(new Node(0, 79));
        adj_list.get(1).add(new Node(1, 0));
        adj_list.get(1).add(new Node(2, 385));
        adj_list.get(1).add(new Node(3, 870));
        adj_list.get(1).add(new Node(4, 1265));
        adj_list.get(1).add(new Node(5, 88));
        adj_list.get(1).add(new Node(6, 627));
        adj_list.get(1).add(new Node(7, 1037));
        adj_list.get(1).add(new Node(8, 876));
        adj_list.get(1).add(new Node(9, 790));
        adj_list.get(1).add(new Node(10, 685));
        adj_list.get(1).add(new Node(11, 912));
        //from madinah to others
        adj_list.get(2).add(new Node(0, 420));
        adj_list.get(2).add(new Node(1, 358));
        adj_list.get(2).add(new Node(2, 0));
        adj_list.get(2).add(new Node(3, 848));
        adj_list.get(2).add(new Node(4, 1343));
        adj_list.get(2).add(new Node(5, 446));
        adj_list.get(2).add(new Node(6, 985));
        adj_list.get(2).add(new Node(7, 679));
        adj_list.get(2).add(new Node(8, 518));
        adj_list.get(2).add(new Node(9, 432));
        adj_list.get(2).add(new Node(10, 1043));
        adj_list.get(2).add(new Node(11, 1270));
        //from riyadh to others
        adj_list.get(3).add(new Node(0, 949));
        adj_list.get(3).add(new Node(1, 870));
        adj_list.get(3).add(new Node(2, 848));
        adj_list.get(3).add(new Node(3, 0));
        adj_list.get(3).add(new Node(4, 395));
        adj_list.get(3).add(new Node(5, 782));
        adj_list.get(3).add(new Node(6, 1064));
        adj_list.get(3).add(new Node(7, 1304));
        adj_list.get(3).add(new Node(8, 330));
        adj_list.get(3).add(new Node(9, 640));
        adj_list.get(3).add(new Node(10, 1272));
        adj_list.get(3).add(new Node(11, 950));
        ////dammam to others
        adj_list.get(4).add(new Node(0, 1343));
        adj_list.get(4).add(new Node(1, 1265));
        adj_list.get(4).add(new Node(2, 1343));
        adj_list.get(4).add(new Node(3, 395));
        adj_list.get(4).add(new Node(4, 0));
        adj_list.get(4).add(new Node(5, 1177));
        adj_list.get(4).add(new Node(6, 1459));
        adj_list.get(4).add(new Node(7, 1729));
        adj_list.get(4).add(new Node(8, 725));
        adj_list.get(4).add(new Node(9, 1035));
        adj_list.get(4).add(new Node(10, 1667));
        adj_list.get(4).add(new Node(11, 1345));
        //Taif to others
        adj_list.get(5).add(new Node(0, 167));
        adj_list.get(5).add(new Node(1, 88));
        adj_list.get(5).add(new Node(2, 446));
        adj_list.get(5).add(new Node(3, 782));
        adj_list.get(5).add(new Node(4, 1177));
        adj_list.get(5).add(new Node(5, 0));
        adj_list.get(5).add(new Node(6, 561));
        adj_list.get(5).add(new Node(7, 1204));
        adj_list.get(5).add(new Node(8, 936));
        adj_list.get(5).add(new Node(9, 957));
        adj_list.get(5).add(new Node(10, 763));
        adj_list.get(5).add(new Node(11, 864));
        //abha to others
        adj_list.get(6).add(new Node(0, 625));
        adj_list.get(6).add(new Node(1, 626));
        adj_list.get(6).add(new Node(2, 985));
        adj_list.get(6).add(new Node(3, 1064));
        adj_list.get(6).add(new Node(4, 1495));
        adj_list.get(6).add(new Node(5, 561));
        adj_list.get(6).add(new Node(6, 0));
        adj_list.get(6).add(new Node(7, 1649));
        adj_list.get(6).add(new Node(8, 1488));
        adj_list.get(6).add(new Node(9, 1402));
        adj_list.get(6).add(new Node(10, 202));
        adj_list.get(6).add(new Node(11, 280));
        //tabuk to others
        adj_list.get(7).add(new Node(0, 1024));
        adj_list.get(7).add(new Node(1, 1037));
        adj_list.get(7).add(new Node(2, 679));
        adj_list.get(7).add(new Node(3, 1304));
        adj_list.get(7).add(new Node(4, 1729));
        adj_list.get(7).add(new Node(5, 1204));
        adj_list.get(7).add(new Node(6, 1649));
        adj_list.get(7).add(new Node(7, 0));
        adj_list.get(7).add(new Node(8, 974));
        adj_list.get(7).add(new Node(9, 664));
        adj_list.get(7).add(new Node(10, 1722));
        adj_list.get(7).add(new Node(11, 1929));
        //Qasim to others
        adj_list.get(8).add(new Node(0, 863));
        adj_list.get(8).add(new Node(1, 876));
        adj_list.get(8).add(new Node(2, 518));
        adj_list.get(8).add(new Node(3, 330));
        adj_list.get(8).add(new Node(4, 725));
        adj_list.get(8).add(new Node(5, 936));
        adj_list.get(8).add(new Node(6, 1488));
        adj_list.get(8).add(new Node(7, 974));
        adj_list.get(8).add(new Node(8, 0));
        adj_list.get(8).add(new Node(9, 974));
        adj_list.get(8).add(new Node(10, 1561));
        adj_list.get(8).add(new Node(11, 1280));
        //hail to others
        adj_list.get(9).add(new Node(0, 777));
        adj_list.get(9).add(new Node(1, 790));
        adj_list.get(9).add(new Node(2, 432));
        adj_list.get(9).add(new Node(3, 640));
        adj_list.get(9).add(new Node(4, 1035));
        adj_list.get(9).add(new Node(5, 957));
        adj_list.get(9).add(new Node(6, 1402));
        adj_list.get(9).add(new Node(7, 664));
        adj_list.get(9).add(new Node(8, 310));
        adj_list.get(9).add(new Node(9, 0));
        adj_list.get(9).add(new Node(10, 1475));
        adj_list.get(9).add(new Node(11, 1590));
        //jizan to others
        adj_list.get(10).add(new Node(0, 710));
        adj_list.get(10).add(new Node(1, 685));
        adj_list.get(10).add(new Node(2, 1043));
        adj_list.get(10).add(new Node(3, 1272));
        adj_list.get(10).add(new Node(4, 1667));
        adj_list.get(10).add(new Node(5, 763));
        adj_list.get(10).add(new Node(6, 202));
        adj_list.get(10).add(new Node(7, 1722));
        adj_list.get(10).add(new Node(8, 1561));
        adj_list.get(10).add(new Node(9, 1475));
        adj_list.get(10).add(new Node(10, 0));
        adj_list.get(10).add(new Node(11, 482));
        //Najran to others 
        adj_list.get(11).add(new Node(0, 905));
        adj_list.get(11).add(new Node(1, 912));
        adj_list.get(11).add(new Node(2, 1270));
        adj_list.get(11).add(new Node(3, 950));
        adj_list.get(11).add(new Node(4, 1345));
        adj_list.get(11).add(new Node(5, 864));
        adj_list.get(11).add(new Node(6, 280));
        adj_list.get(11).add(new Node(7, 1929));
        adj_list.get(11).add(new Node(8, 1280));
        adj_list.get(11).add(new Node(9, 1590));
        adj_list.get(11).add(new Node(10, 482));
        adj_list.get(11).add(new Node(11, 0));

        System.out.println("-------------- CPCS324 Project - Phase1 - Group4 --------------");
        System.out.println("Implement Dijkstra algorithm to find The shorted path from Jeddah to other cities \"tracing:\"");
        System.out.println("\n\n----------------------");

        // call Dijkstra's algo method  
        Graph_pq dpq = new Graph_pq(V);
        dpq.algo_dijkstra(adj_list, source);
        
        // Print the shortest path from source node to all the nodes 
        ArrayList<city> sortedCity = new ArrayList<city>(V);//Creating arraylist 
        System.out.println("\n- Final Tree Vertices:");
        for (int i = 0; i < dpq.dist.length; i++) {
            sortedCity.add(new city(i, dpq.dist[i]));
        }
        sortedCity.sort(Comparator.comparingInt(o -> o.distance));
        for (int i = 0; i < sortedCity.size(); i++) {
            System.out.println(sortedCity.get(i).destination + "\t ("+sortedCity.get(i).source+" ," + sortedCity.get(i).distance + ")");
        }
        System.out.println("\n----------------------");

    }

}

class city {

    String source;
    String destination;
    int distance;

    public city(int destination, int distance) {
        if (distance == 0) {
            this.source = "-";
        } else {
            this.source = "Jeddah";
        }

        switch (destination) {
            case 0:
                this.destination = "Jeddah";
                break;
            case 1:
                this.destination = "Makkah";
                break;
            case 2:
                this.destination = "Mdinah";
                break;
            case 3:
                this.destination = "Riyadh";
                break;
            case 4:
                this.destination = "Dammam";
                break;
            case 5:
                this.destination = "Taif";
                break;
            case 6:
                this.destination = "Abha";
                break;
            case 7:
                this.destination = "Tabuk";
                break;
            case 8:
                this.destination = "Qasim";
                break;
            case 9:
                this.destination = "Hail";
                break;
            case 10:
                this.destination = "Jizan";
                break;
            case 11:
                this.destination = "Najran";
                break;
        }
        this.distance = distance;
    }

}

// Node class  
class Node implements Comparator<Node> {

    public int node;
    public int cost;

    public Node() {
    } //empty constructor 

    public Node(int node, int cost) {
        this.node = node;
        this.cost = cost;
    }

    @Override
    public int compare(Node node1, Node node2) {
        if (node1.cost < node2.cost) {
            return -1;
        }
        if (node1.cost > node2.cost) {
            return 1;
        }
        return 0;
    }
}
