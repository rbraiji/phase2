package cpcs324.project.phase2;

// Group 4: 
// Ethar Nasser Alahmari 1807758
// Rahaf Ibrahim Braiji 1805651
// Sara Abdulilah Alhaifi 1807468

/* To display the tracing of algorithm uncomment following lines: 
    Kruskal Algorithm:
        Tracing: Display first Sorted List of edge 
        234-239
        Tracing: Display Sorted List of edge
        259-263
        Tracing: Display Tree edge
        273-277
        Tracing: Minimum Spanning Tree Edges
        291

    Prim Algorithm Based on Priority Queue:
        Tracing: Display first Tree Vertex
        390-400
        Tracing: Display Tree Vertices
        428-438
        Tracing: Minimum Spanning Tree Vertices
        456-463


    Prim’s algorithm using min-heap:
        Tracing: Display first Tree Vertex
        527-529
        Tracing: Display Tree Vertex
        569-578
        Tracing: Minimum Spanning Tree Vertex
        604-611
*/

import java.util.*;
import java.io.*;
import javafx.util.Pair;

public class CPCS324ProjectPhase2 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // display cases
        System.out.println("-------------- CPCS324 Project - Phase1 - Group4 --------------");
        System.out.println("\nSelect one of the following cases to generate a graph:\n");
        System.out.println("\t         Vertices \tEdges\n"
                + "\t        -----------------------\n"
                + "\tCase 1:\t   1000\t\t10000 \n"
                + "\tCase 2:\t   1000\t\t15000 \n"
                + "\tCase 3:\t   1000\t\t25000 \n"
                + "\tCase 4:\t   5000\t\t15000 \n"
                + "\tCase 5:\t   5000\t\t25000 \n"
                + "\tCase 6:\t   10000\t15000 \n"
                + "\tCase 7:\t   10000\t25000 \n"
                + "\tCase 8:\t   20000\t200000 \n"
                + "\tCase 9:\t   20000\t300000 \n"
                + "\tCase 10:   50000\t1000000 \n");
        System.out.print("Enter Your case Number: ");
        int choice = input.nextInt();
        make_graph(choice);
    }

////////////////////////////////// Make Graph Randomly /////////////////////////////////
    public static void make_graph(int choice) {
        int numberofV = 0, numberofE = 0;
        switch (choice) {
            case 1:
                numberofV = 1000;
                numberofE = 10000;
                break;
            case 2:
                numberofV = 1000;
                numberofE = 15000;
                break;
            case 3:
                numberofV = 1000;
                numberofE = 25000;
                break;
            case 4:
                numberofV = 5000;
                numberofE = 15000;
                break;
            case 5:
                numberofV = 5000;
                numberofE = 25000;
                break;
            case 6:
                numberofV = 10000;
                numberofE = 15000;
                break;
            case 7:
                numberofV = 10000;
                numberofE = 25000;
                break;
            case 8:
                numberofV = 20000;
                numberofE = 200000;
                break;
            case 9:
                numberofV = 20000;
                numberofE = 300000;
                break;
            case 10:
                numberofV = 50000;
                numberofE = 1000000;
                break;
        }
        int infinity = -999;

        // Make graph
        int[][] adj = new int[numberofV][numberofV];
        initializeMatrix(numberofV, numberofE, adj, infinity);
        int currentNumberofE = addNewVertices(numberofV, numberofE, adj);
        addNewEdges(numberofV, numberofE, adj, infinity, currentNumberofE);

        // Kruskal Algorithm
        long startTime = System.currentTimeMillis();
        Kruskal kruskalAlgorithms = new Kruskal(numberofV);
        kruskalAlgorithms.kruskalMST(numberofV, infinity, adj);
        long endTime = System.currentTimeMillis();
        long totalTime = endTime - startTime; // calculate run time of Kruskal Algorithm
        System.out.println("Total time in Second: " + (totalTime / 1000.0) + "\n");

        // Priority-Queue based Prim Algorithm 
        startTime = System.currentTimeMillis();
        PrimPQ primPQ = new PrimPQ(numberofV);
        primPQ.primMST(numberofV, infinity, adj);
        endTime = System.currentTimeMillis();
        totalTime = endTime - startTime; // calculate run time of Priority-Queue based Prim Algorithm  
        System.out.println("Total time in Second: " + (totalTime / 1000.0) + "\n");

        // Prim’s algorithm using min-heap
        startTime = System.currentTimeMillis();
        PrimMH primMH = new PrimMH(numberofV);
        primMH.primMST(numberofV, infinity, adj);
        endTime = System.currentTimeMillis();
        totalTime = endTime - startTime; // calculate run time of Prim’s algorithm using min-heap
        System.out.println("Total time in Second: " + (totalTime / 1000.0) + "\n");
    }

    // initialize the adjacency matrix with infinity and the diagonal with 0
    public static void initializeMatrix(int numberofV, int numberofE, int[][] matrix, int infinity) {
        for (int i = 0; i < numberofV; i++) {
            for (int j = 0; j < numberofV; j++) {
                if (i == j) {
                    matrix[i][j] = 0; // initialize the diagonal of adjacency matrix with 0
                } else {
                    matrix[i][j] = infinity; // initialize the remain adjacency matrix with infinity
                }

            }
        }

    }

    // Generate connected graph by adding new vertices and connect them to random previous vertices
    // and return how many edges the graph has now.
    public static int addNewVertices(int numberofV, int numberofE, int[][] matrix) {
        int randomExistingV = 1;
        int currentNumberofE = 0;
        Random random = new Random();
        //Connect each vertex with the the previous one
        for (int currentVertice = 1; currentVertice < numberofV + 1; currentVertice++) {
            if (currentVertice > 1) {
                randomExistingV = random.nextInt(currentVertice - 1) % (currentVertice - 1) + 1;
            }
            if (currentVertice != randomExistingV) {
                //Create an edge between the two vertices and assign a random weight between 1-10
                matrix[currentVertice - 1][randomExistingV - 1]
                        = matrix[randomExistingV - 1][currentVertice - 1]
                        = (int) (Math.random() * 10) + 1;
                currentNumberofE++;
            }
        }
        return currentNumberofE;
    }

    //Add new edges to reach the required edge number.
    public static void addNewEdges(int numberofV, int numberofE, int[][] matrix, int infinity, int currentNumberofE) {
        Random random = new Random();
        while (currentNumberofE < numberofE) {

            //Select two random vertices to connect them by an edge
            int ver1 = random.nextInt(numberofV) % (numberofV) + 1;
            int ver2 = random.nextInt(numberofV) % (numberofV) + 1;

            //Check if the edge is already exist, select another two random vertices
            while (matrix[ver1 - 1][ver2 - 1] != infinity) {
                ver2 = random.nextInt(numberofV) % (numberofV) + 1;
                ver1 = random.nextInt(numberofV) % (numberofV) + 1;
            }

            //Assign a random weight between 0 - 10 for the edge
            matrix[ver1 - 1][ver2 - 1] = matrix[ver2 - 1][ver1 - 1] = (int) (Math.random() * 10) + 1;
            currentNumberofE++;
        }
    }

    //class contain edge properties
    static class Edge {

        int source;
        int destination;
        int weight;

        public Edge() {
        }

        public Edge(int source, int destination, int weight) {
            this.source = source;
            this.destination = destination;
            this.weight = weight;
        }

    }

    static class ResultSet {

        int parent;
        int weight;
    }

//////////////////////////////////  Kruskal Algorithm /////////////////////////////////     
    static class Kruskal {

        int vertices;
        ArrayList<Edge> allEdges = new ArrayList<>();

        Kruskal(int vertices) {
            this.vertices = vertices;
        }

        public void kruskalMST(int numberOfVertices, int MAX_VALUE, int adjacencyMatrix[][]) {
            /* Modify to convert adjacency matrix to List of edges*/
            // check if there is an edge between each two vertices, and add it to edges list
            for (int source = 0; source < numberOfVertices; source++) {
                for (int destination = 0; destination < numberOfVertices; destination++) {
                    if (adjacencyMatrix[source][destination] != MAX_VALUE && source != destination) {
                        Edge edge = new Edge();
                        edge.source = source;
                        edge.destination = destination;
                        edge.weight = adjacencyMatrix[source][destination];
                        adjacencyMatrix[destination][source] = MAX_VALUE;
                        allEdges.add(edge);
                    }
                }
            }
            System.out.println("\n----------- Kruskal Algorithm ------------\n");

            // Add and sort all the edges based on their weight
            PriorityQueue<Edge> pq = new PriorityQueue<>(allEdges.size(), Comparator.comparingInt(o -> o.weight));
            for (int i = 0; i < allEdges.size(); i++) {
                pq.add(allEdges.get(i));
            }
            allEdges.sort(Comparator.comparingInt(o -> o.weight));

            // Tracing: Display first Sorted List of edge
//            System.out.println("Initial sorted list of edges:");
//            for (int i = 0; i < allEdges.size(); i++) {
//                System.out.println("Source: " + allEdges.get(i).source + ", Destination: " + allEdges.get(i).destination + ", Weight: " + allEdges.get(i).weight);
//            }
//            System.out.println("");
//            System.out.println("\n------------\n");

            // Create a parent []
            int[] parent = new int[vertices];

            // Makeset of all vertices
            makeSet(parent);

            // List contains minium spanning tree edges
            ArrayList<Edge> mst = new ArrayList<>();

            int index = 0;
            while (index < vertices - 1) {
                Edge edge = pq.remove();

                //check if adding this edge creates a cycle
                int x_set = find(parent, edge.source);
                int y_set = find(parent, edge.destination);
                
                // Tracing: Display Sorted List of edge
//                System.out.println("- Sorted list of edges:");
//                allEdges.remove(allEdges.get(0));
//                for (int i = 0; i < allEdges.size(); i++) {
//                    System.out.println("Source: " + allEdges.get(i).source + ", Destination: " + allEdges.get(i).destination + ", Weight: " + allEdges.get(i).weight);
//                }
                if (x_set == y_set) {
                    //ignore because this edge will create cycle
                } else {
                    //add it to minimum spanning tree list
                    mst.add(edge);
                    index++;
                    union(parent, x_set, y_set);
                }
                // Tracing: Display Tree edge
//                System.out.println("- Tree Edge:");
//                for (int j = 0; j < mst.size(); j++) {
//                    System.out.println("Source: " + mst.get(j).source + ", Destination: " + mst.get(j).destination + ", Weight: " + mst.get(j).weight);
//                }
//                System.out.println("\n------------\n");

            }
            //print minimum spanning tree information
            printMST(mst);
        }

        public void printMST(ArrayList<Edge> mst) {
            // Calculate the minimum spanning tree cost
            int MST = 0;
            //System.out.println("- Minimum Spanning Tree Edges");
            for (int i = 0; i < mst.size(); i++) {
                MST += mst.get(i).weight;
                // Tracing: Minimum Spanning Tree Edges
                //System.out.println("Source: " + mst.get(i).source + ", Destination: " + mst.get(i).destination + ", Weight: " + mst.get(i).weight);

            }
            System.out.println("\nTotal Minimum Spanning Tree Cost: " + MST);
        }

        public void makeSet(int[] parent) {
            //Make set- creating a new element with a parent pointer to itself.
            for (int i = 0; i < vertices; i++) {
                parent[i] = i;
            }
        }

        public int find(int[] parent, int vertex) {
            //chain of parent pointers from x upwards through the tree
            // until an element is reached whose parent is itself
            if (parent[vertex] != vertex) {
                return find(parent, parent[vertex]);
            };
            return vertex;
        }

        public void union(int[] parent, int x, int y) {
            int x_set_parent = find(parent, x);
            int y_set_parent = find(parent, y);
            //make x as parent of y
            parent[y_set_parent] = x_set_parent;
        }

    }

////////////////////////////// Priority-Queue based Prim Algorithm //////////////////////////////
    static class PrimPQ {

        int vertices;
        LinkedList<Edge>[] adjacencylist;

        PrimPQ(int vertices) {
            this.vertices = vertices;
            adjacencylist = new LinkedList[vertices];
            //initialize adjacency lists for all the vertices
            for (int i = 0; i < vertices; i++) {
                adjacencylist[i] = new LinkedList<>();
            }
        }

        public void addEgde(int source, int destination, int weight) {
            Edge edge = new Edge(source, destination, weight);
            adjacencylist[source].addFirst(edge);

            edge = new Edge(destination, source, weight);
            adjacencylist[destination].addFirst(edge); //for undirected graph
        }

        public void primMST(int numberOfVertices, int MAX_VALUE, int adjacencyMatrix[][]) {
            /* Modify to convert adjacency matrix to List of edges*/
            // check if there is an edge between each two vertices, and add it to adjacencylist
            for (int source = 0; source < numberOfVertices; source++) {
                for (int destination = 0; destination < numberOfVertices; destination++) {
                    if (adjacencyMatrix[source][destination] != MAX_VALUE && source != destination) {
                        addEgde(source, destination, adjacencyMatrix[source][destination]);
                    }
                }
            }

            System.out.println("----------- Prim Based on Priority Queue ------------\n");
            boolean[] mst = new boolean[vertices];
            ResultSet[] resultSet = new ResultSet[vertices];
            int[] key = new int[vertices];  //keys used to store the key to know whether priority queue update is required

            //Initialize all the keys to infinity and
            //initialize resultSet for all the vertices
            for (int i = 0; i < vertices; i++) {
                key[i] = Integer.MAX_VALUE;
                resultSet[i] = new ResultSet();
            }

            //Initialize priority queue
            //override the comparator to do the sorting based keys
            PriorityQueue<Pair<Integer, Integer>> pq = new PriorityQueue<>(vertices, new Comparator<Pair<Integer, Integer>>() {
                @Override
                public int compare(Pair<Integer, Integer> p1, Pair<Integer, Integer> p2) {
                    //sort using key values
                    int key1 = p1.getKey();
                    int key2 = p2.getKey();
                    return key1 - key2;
                }
            });

            //create the pair for for the first index, 0 key 0 index
            key[0] = 0;
            Pair<Integer, Integer> p0 = new Pair<>(key[0], 0);
            //add it to pq
            pq.offer(p0);

            resultSet[0] = new ResultSet();
            resultSet[0].parent = -1;

            //Tracing: Display first Tree Vertex
//            System.out.println("- Tree Vertices: ");
//            for (int j = 0; j < resultSet.length; j++) {
//                if (resultSet[j].parent != 0 || resultSet[j].weight != 0) {
//                    if (j == 0) {
//                        System.out.println(j + " (-,-)");
//                    } else {
//                        System.out.println(j + " (" + resultSet[j].parent + "," + resultSet[j].weight + ")");
//                    }
//                }
//            }
//            System.out.println("\n------------\n");
            
            //while priority queue is not empty
            while (!pq.isEmpty()) {
                //extract the min
                Pair<Integer, Integer> extractedPair = pq.poll();

                //extracted vertex
                int extractedVertex = extractedPair.getValue();
                mst[extractedVertex] = true;

                //iterate through all the adjacent vertices and update the keys
                LinkedList<Edge> list = adjacencylist[extractedVertex];
                for (int i = 0; i < list.size(); i++) {
                    Edge edge = list.get(i);
                    //only if edge destination is not present in mst
                    if (mst[edge.destination] == false) {
                        int destination = edge.destination;
                        int newKey = edge.weight;
                        //check if updated key < existing key, if yes, update if
                        if (key[destination] > newKey) {
                            //add it to the priority queue
                            Pair<Integer, Integer> p = new Pair<>(newKey, destination);
                            pq.offer(p);
                            //update the resultSet for destination vertex
                            resultSet[destination].parent = extractedVertex;
                            resultSet[destination].weight = newKey;
                            //Tracing: Display Tree Vertices
//                            System.out.println("- Tree Vertices");
//                            for (int j = 0; j < resultSet.length; j++) {
//                                if (resultSet[j].parent != 0 || resultSet[j].weight != 0) {
//                                    if (j == 0) {
//                                        System.out.println(j + " (-,-)");
//                                    } else {
//                                        System.out.println(j + " (" + resultSet[j].parent + "," + resultSet[j].weight + ")");
//                                    }
//                                }
//                            }
//                            System.out.println("\n------------\n");
                            
                            //update the key[]
                            key[destination] = newKey;
                        }
                    }
                }
            }
            //print minimum spanning tree information
            printMST(resultSet);
        }

        public void printMST(ResultSet[] resultSet) {
            int total_min_weight = 0;
            for (int i = 1; i < vertices; i++) {
                total_min_weight += resultSet[i].weight;
            }
            // Tracing: Minimum Spanning Tree Vertices
//            System.out.println("- Minimum Spanning Tree Vertices: ");
//            for (int i = 0; i < resultSet.length; i++) {
//                if (i == 0) {
//                    System.out.println(i + " (-,-)");
//                } else {
//                    System.out.println(i + " (" + resultSet[i].parent + "," + resultSet[i].weight + ")");
//                }
//            }
            System.out.println("\nTotal Minimum Spanning Tree Cost: " + total_min_weight);
        }
    }

////////////////////////////////// Prim’s algorithm using min-heap /////////////////////////////////     
    static class HeapNode {

        int vertex;
        int key;
    }

    static class PrimMH {

        int vertices;
        LinkedList<Edge>[] adjacencylist;

        PrimMH(int vertices) {
            this.vertices = vertices;
            adjacencylist = new LinkedList[vertices];
            //initialize adjacency lists for all the vertices
            for (int i = 0; i < vertices; i++) {
                adjacencylist[i] = new LinkedList<>();
            }
        }

        public void addEdge(int source, int destination, int weight) {
            Edge edge = new Edge(source, destination, weight);
            adjacencylist[source].addFirst(edge);

            edge = new Edge(destination, source, weight);
            adjacencylist[destination].addFirst(edge); //for undirected graph
        }

        public void primMST(int numberOfVertices, int MAX_VALUE, int adjacencyMatrix[][]) {
            /* Modify to convert adjacency matrix to List of edges*/
            // check if there is an edge between each two vertices, and add it to adjacencylist
            for (int source = 0; source < numberOfVertices; source++) {
                for (int destination = 0; destination < numberOfVertices; destination++) {
                    if (adjacencyMatrix[source][destination] != MAX_VALUE && source != destination) {
                        addEdge(source, destination, adjacencyMatrix[source][destination]);
                    }
                }
            }

            System.out.println("----------- Prim’s algorithm using min-heap ------------\n");
            
            boolean[] inHeap = new boolean[vertices];
            ResultSet[] resultSet = new ResultSet[vertices];
            //keys[] used to store the key to know whether min hea update is required
            int[] key = new int[vertices];
            //create heapNode for all the vertices
            HeapNode[] heapNodes = new HeapNode[vertices];
            for (int i = 0; i < vertices; i++) {
                heapNodes[i] = new HeapNode();
                heapNodes[i].vertex = i;
                heapNodes[i].key = Integer.MAX_VALUE;
                resultSet[i] = new ResultSet();
                resultSet[i].parent = -1;
                inHeap[i] = true;
                key[i] = Integer.MAX_VALUE;
            }

            //Tracing: Display first Tree Vertex
//            System.out.println("- Tree Vertex");
//            System.out.println("0 (-,-)");
//            System.out.println("\n------------\n");
            
            //decrease the key for the first index
            heapNodes[0].key = 0;

            //add all the vertices to the MinHeap
            MinHeap minHeap = new MinHeap(vertices);
            //add all the vertices to priority queue
            for (int i = 0; i < vertices; i++) {
                minHeap.insert(heapNodes[i]);
            }

            //while minHeap is not empty
            while (!minHeap.isEmpty()) {
                //extract the min
                HeapNode extractedNode = minHeap.extractMin();

                //extracted vertex
                int extractedVertex = extractedNode.vertex;
                inHeap[extractedVertex] = false;

                //iterate through all the adjacent vertices
                LinkedList<Edge> list = adjacencylist[extractedVertex];
                for (int i = 0; i < list.size(); i++) {
                    Edge edge = list.get(i);
                    
                    //only if edge destination is present in heap
                    if (inHeap[edge.destination]) {
                        int destination = edge.destination;
                        int newKey = edge.weight;
                        //check if updated key < existing key, if yes, update if
                        
                        if (key[destination] > newKey) {
                            decreaseKey(minHeap, newKey, destination);
                            //update the parent node for destination
                            resultSet[destination].parent = extractedVertex;
                            resultSet[destination].weight = newKey;
                            key[destination] = newKey;
                            
                            //Tracing: Display Tree Vertex                            
//                            System.out.println("- Tree Vertices:");
//                            for (int j = 0; j < resultSet.length; j++) {
//                                if (j == 0) {
//                                        System.out.println(j + " (-,-)");
//                                    }
//                                if (resultSet[j].parent != -1 || resultSet[j].weight != 0) {
//                                   System.out.println(j + " (" + resultSet[j].parent + "," + resultSet[j].weight + ")");
//                                }
//                            }
//                            System.out.println("\n------------\n");
                        }
                    }
                }
            }
            //print mst
            printMST(resultSet);
        }

        public void decreaseKey(MinHeap minHeap, int newKey, int vertex) {

            //get the index which key's needs a decrease;
            int index = minHeap.indexes[vertex];

            //get the node and update its value
            HeapNode node = minHeap.mH[index];
            node.key = newKey;
            minHeap.bubbleUp(index);
        }

        public void printMST(ResultSet[] resultSet) {
            int total_min_weight = 0;
            for (int i = 1; i < vertices; i++) {
                total_min_weight += resultSet[i].weight;
            }
            //Tracing: Minimum Spanning Tree Vertex
//            System.out.println("- Minimum Spanning Tree Vertex");
//            for (int i = 0; i < resultSet.length; i++) {
//                if (i == 0) {
//                    System.out.println(i + " (-,-)");
//                } else {
//                    System.out.println(i + " (" + resultSet[i].parent + "," + resultSet[i].weight + ")");
//                }
//            }
            System.out.println("\nTotal Minimum Spanning Tree Cost: " + total_min_weight);
        }
    }

    static class MinHeap {

        int capacity;
        int currentSize;
        HeapNode[] mH;
        int[] indexes; //will be used to decrease the key

        public MinHeap(int capacity) {
            this.capacity = capacity;
            mH = new HeapNode[capacity + 1];
            indexes = new int[capacity];
            mH[0] = new HeapNode();
            mH[0].key = Integer.MIN_VALUE;
            mH[0].vertex = -1;
            currentSize = 0;
        }

        public void display() {
            for (int i = 0; i <= currentSize; i++) {
                System.out.println(" " + mH[i].vertex + "   key   " + mH[i].key);
            }
            System.out.println("________________________");
        }

        public void insert(HeapNode x) {
            currentSize++;
            int idx = currentSize;
            mH[idx] = x;
            indexes[x.vertex] = idx;
            bubbleUp(idx);
        }

        public void bubbleUp(int pos) {
            int parentIdx = pos / 2;
            int currentIdx = pos;
            while (currentIdx > 0 && mH[parentIdx].key > mH[currentIdx].key) {
                HeapNode currentNode = mH[currentIdx];
                HeapNode parentNode = mH[parentIdx];

                //swap the positions
                indexes[currentNode.vertex] = parentIdx;
                indexes[parentNode.vertex] = currentIdx;
                swap(currentIdx, parentIdx);
                currentIdx = parentIdx;
                parentIdx = parentIdx / 2;
            }
        }

        public HeapNode extractMin() {
            HeapNode min = mH[1];
            HeapNode lastNode = mH[currentSize];
//            update the indexes[] and move the last node to the top
            indexes[lastNode.vertex] = 1;
            mH[1] = lastNode;
            mH[currentSize] = null;
            sinkDown(1);
            currentSize--;
            return min;
        }

        public void sinkDown(int k) {
            int smallest = k;
            int leftChildIdx = 2 * k;
            int rightChildIdx = 2 * k + 1;
            if (leftChildIdx < heapSize() && mH[smallest].key > mH[leftChildIdx].key) {
                smallest = leftChildIdx;
            }
            if (rightChildIdx < heapSize() && mH[smallest].key > mH[rightChildIdx].key) {
                smallest = rightChildIdx;
            }
            if (smallest != k) {

                HeapNode smallestNode = mH[smallest];
                HeapNode kNode = mH[k];

                //swap the positions
                indexes[smallestNode.vertex] = k;
                indexes[kNode.vertex] = smallest;
                swap(k, smallest);
                sinkDown(smallest);
            }
        }

        public void swap(int a, int b) {
            HeapNode temp = mH[a];
            mH[a] = mH[b];
            mH[b] = temp;
        }

        public boolean isEmpty() {
            return currentSize == 0;
        }

        public int heapSize() {
            return currentSize;
        }
    }
}
